const {Router} = require ('express')
const router =Router()

const {getPersons, createPerson} = require('../controllers/index.controller')

router.get('/persons', getPersons)
router.post('/createPersons', createPerson)

module.exports = router