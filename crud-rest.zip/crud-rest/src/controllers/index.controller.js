const { Pool } = require('pg')
const pool = new Pool({
    host: 'postgres',
    user: 'user',
    password: 'pass',
    database: 'db',
    port: '5432'
})
const fs = require("fs")
const path = require('path')
console.log(__dirname);
var data = fs.readFileSync(path.join(__dirname, '../databse.sql'), { encoding: 'utf8', flag: 'r' });
console.log(data)
try {
    pool.query(data)
} catch (error) {
    console.log(error)
}

const getPersons = async (req, res) => {
    try {
        const response = await pool.query('SELECT * FROM persons');
        res.status(200).json(response.rows)
    } catch (error) {
        console.log(error)
    }

}
const createPerson = async (req, res) => {
    const { fullname, birth, mother, father, children } = req.body
    try {
        const response = await pool.query('INSERT INTO users(name,email,mother, father, children) VALUES ($1, $2, $3, $4,$5)', [fullname, birth, mother, father, children])
        res.json({
            message: 'Person Added Succesfully',
            body: {
                person: { fullname, birth }
            }
        })
    } catch (error) {
        console.log(error)
    }

}

module.exports = {
    getPersons,
    createPerson
}
