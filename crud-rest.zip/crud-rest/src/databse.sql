CREATE TABLE persons(
    id SERIAL PRIMARY KEY,
    fullname VARCHAR(40) NOT NULL,
    birth DATE NOT NULL,
    mother Integer NOT NULL,
    father Integer NOT NULL,
    childS Integer []
);
